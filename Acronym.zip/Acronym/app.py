from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from decimal import Decimal


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
app.app_context().push()

class Test(db.Model):
    Invoice = db.Column(db.Integer, primary_key=True)
    Date_d = db.Column(db.DateTime, default=datetime.utcnow)
    Party_name = db.Column(db.String(200), nullable=False)
    Gst_number = db.Column(db.String)
    Taxable_value = db.Column(db.String(200), nullable=False)
    Cgst = db.Column(db.Numeric(10,2))
    Sgst = db.Column(db.Numeric(10))
    Igst = db.Column(db.Float)
    Gst_value = db.Column(db.Numeric(10))
    Invoice_value = db.Column(db.Numeric(10))

    def __repr__(self):
        return f'test {self.Party_name}'


@app.route('/')
def hello_world():
    return render_template("home.html")

@app.route('/sales', methods=['GET', 'POST'])
def sales():
    if request.method == "POST":
        try:
            Invoice = int(request.form['Invoice'])
            Date_d_str = request.form['Date_d']
            Party_name = request.form['Party_name']
            Gst_number = request.form['Gst_number']
            Taxable_value = float(request.form.get('Taxable_value'))
            if request.form.get('agreeToTerms'):
                Cgst = round(Taxable_value * (9 / 100), 2)
                Sgst = round(Taxable_value * (9 / 100), 2)
                Igst = 0  # Set Igst to 0 when checkbox is checked
            else:
                Cgst = 0
                Sgst = 0
                Igst = round(Taxable_value * (18 / 100), 2)
            Gst_value = Cgst + Sgst + Igst #float(request.form['Gst_value'])
            Invoice_value = Taxable_value + Gst_value
            

            # Validate and convert Date_d_str to a datetime object
            if Date_d_str:
                Date_d = datetime.strptime(Date_d_str, '%Y-%m-%d')
            else:
                flash('Date is required', 'error')
                return redirect(url_for('error'))

            test = Test(
                Invoice=Invoice,
                Date_d=Date_d,
                Party_name=Party_name,
                Gst_number=Gst_number,
                Taxable_value=Taxable_value,
                Cgst=Cgst,
                Sgst=Sgst,
                Igst=Igst,
                Gst_value=Gst_value,
                Invoice_value=Invoice_value
            )

            db.session.add(test)
            db.session.commit()

        except ValueError as e:
            db.session.rollback()
            print(f"Error: {e}")
            flash('Invalid data format', 'error')
            return redirect(url_for('error'))

    all_test_instances = Test.query.all()
    return render_template("sales.html", alltest=all_test_instances)


@app.route('/purchase')
def purchase():
    all_test_instances = Test.query.all()
    print(all_test_instances)
    return render_template("purchase.html")

@app.route('/taxable')
def tax():
    return render_template("taxable.html")

@app.route('/error')
def error():
    message = request.args.get('message', 'An error occurred.')
    return render_template('error.html', message=message)

if __name__ == "__main__":
    app.run(debug=True)
    #app.run(host="0.0.0.0")
